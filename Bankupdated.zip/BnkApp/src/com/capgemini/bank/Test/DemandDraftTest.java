package com.capgemini.bank.Test;

public class DemandDraftTest {

}
