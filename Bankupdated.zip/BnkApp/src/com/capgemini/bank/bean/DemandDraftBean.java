package com.capgemini.bank.bean;

import java.util.Date;

public class DemandDraftBean {

	private int tranId;
	private String name;
	private String mobNo;
	private String inFavour;
	private String ddAmount;
	private double comm;
	public double getComm() {
		return comm;
	}
	public void setComm(double comm) {
		this.comm = comm;
	}
	private String remarks;
	Date tran_dt;
	public Date getTran_dt() {
		return tran_dt;
	}
	public void setTran_dt(Date tran_dt) {
		this.tran_dt = tran_dt;
	}
	public int getTranId() {
		return tranId;
	}
	public void setTranId(int tranId) {
		this.tranId = tranId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobNo() {
		return mobNo;
	}
	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}
	public String getInFavour() {
		return inFavour;
	}
	public void setInFavour(String inFavour) {
		this.inFavour = inFavour;
	}
	public String getDdAmount() {
		return ddAmount;
	}
	public void setDdAmount(String ddAmount) {
		this.ddAmount = ddAmount;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
}
