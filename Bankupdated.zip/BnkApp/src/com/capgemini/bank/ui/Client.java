package com.capgemini.bank.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraftBean;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exception.BankException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;


public class Client {
	
	public static void main(String[] args) throws BankException, SQLException{
		
		IDemandDraftService dds=new DemandDraftService();
		Scanner sc=new Scanner(System.in);
		IDemandDraftDAO  ddao= new DemandDraftDAO();
		
		DemandDraftBean ddb= new DemandDraftBean();
		do{
			System.out.println("--------------XYZ BANK APPLICATION-----------------");
			
			System.out.println(" ");
			System.out.println("------------------------------------------------------------");
			System.out.println("Choose an operation");
			System.out.println("------------------------------------------------------------");
			System.out.println("1.  Enter Demand Draft Details");
			System.out.println("2.  Print Demand Draft");
			System.out.println("3. Exit");
			System.out.println(" ");
			System.out.println("-----------------------------------------------------------");

int choice=sc.nextInt();
		
		switch(choice){
		
		
		case 1: 
			
			
			
			System.out.println("Enter the Name of the Customer: ");
			ddb.setName(sc.next());
					
			System.out.println("Enter customer Mobile Number: ");
			ddb.setMobNo(sc.next());
			
			System.out.println("IN Favour Of: ");
			ddb.setInFavour(sc.next());
			
			System.out.println("Enter DemandDraft Amount (in Rs.): ");
			ddb.setDdAmount(sc.next());
			
			int amt =Integer.parseInt(ddb.getDdAmount());
			if(amt<=5000){
				int comm=10;
				ddb.setComm(comm);}
			
			else if(amt>=5001 && amt<=10000){
				int comm=41;
				ddb.setComm(comm);
			}
			else if(amt>=10001 && amt<=100000){
				int comm=51;
				ddb.setComm(comm);
			}
			else if(amt>=100001 && amt<=500000){
				int comm=51;
				ddb.setComm(comm);}
			
			System.out.println("Enter Remarks:");
			ddb.setRemarks(sc.next());
			
			
			
			//sc.close();
			
			try{
				if(dds.isValidDemandDraft(ddb)){
					
					ddao.addDD(ddb);
					//Dao.getCallid();
					int id = ddb.getTranId();
					System.out.println("Your Demand Draft request has been successfully registered along with the "+id);
					System.out.println("");
				}
				
			}catch(BankException e){
				e.printStackTrace();
				System.out.println("Please try Again");
			}
			
			
			
			
			
			
			
			
			/*System.out.println("Thank You "+en.getfName()+" "+en.getlName()+" your Unique id is "+en.getEnqryid()+
					" we will contact You Shortly");*/
			
			
			
			
			
			/*cbs.isValidEnquiry(enqry);*/
			
			break;
			
			
		case 2:
			System.out.println("Enter Transaction ID No. ");
			ddao = new DemandDraftDAO();
			
			int tranId= sc.nextInt();
			
			ddb = ddao.getDemandDraft(tranId);
			
		
			double a = Integer.parseInt(ddb.getDdAmount());
			double b = ddb.getComm();
			
			double tot = a+b;
			
			System.out.println("Name of the bank: XYZ"
						   + "\nDD Amount       : Rs."+ddb.getDdAmount()
						   + "\nDD Commision    : Rs."+ddb.getComm()
						   + "\nTotal Amount    : Rs."+tot
						   + "\nRemarks         :"+ddb.getRemarks()
								  );
			System.out.println("");
			break;
			
			
		case 3:System.out.println("Thank You..");
		System.out.println("");
        System.exit(0);
        
        break;
        
		default: System.out.println("Invalid Choice..Try Again..!!");
        
			
		
		}
		
		}while(true);	
		
	}

}
