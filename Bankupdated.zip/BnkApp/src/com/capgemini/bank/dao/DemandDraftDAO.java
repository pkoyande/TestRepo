package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.capgemini.bank.utils.Log4jHTMLLayout;

import com.capgemini.bank.bean.DemandDraftBean;
import com.capgemini.bank.exception.BankException;
import com.capgemini.bank.utils.DBUtils;

public class DemandDraftDAO implements IDemandDraftDAO {

	private static Logger log = Logger.getLogger(Log4jHTMLLayout.class);

	
private Connection dbConnection;
	
	{
		try {
			dbConnection = DBUtils.getConnection();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	int id;
	
	public int transactionId() throws SQLException {
		int id = 0;

		String selectQuery = "select TRANSACTION_ID_SEQ.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result = selectStatement.executeQuery(selectQuery);

		result.next();

		id = result.getInt(1);
		
		
		return id;
	}
	
@Override
	public int addDD(DemandDraftBean dd) throws BankException{
		
		 String insertQuery = "insert into dd values(?,?,?,?,?,?,?,?) ";
		 try{
			 
			 PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
			 
			 insertStatement.setInt(1,  transactionId());
			 
			 insertStatement.setString(2, dd.getName());
			 
			 insertStatement.setString(3, dd.getMobNo());
			 
			 insertStatement.setString(4, dd.getInFavour());
				
			 insertStatement.setDate(5, (Date) dd.getTran_dt());
			 
			 insertStatement.setString(6, dd.getDdAmount());
			 
			 insertStatement.setDouble(7, dd.getComm());
			 
			 insertStatement.setString(8, dd.getRemarks());
			 
			 
			 
				int rows = insertStatement.executeUpdate();
			 
				if(rows>0){
					System.out.println("New DD is Added..");
					System.out.println("");
					log.info("New DD is Added");
					return 1;
				}
				else 
					return 0;
					
			} catch (SQLException e) {
				
				e.printStackTrace();
				log.error(e.getMessage());
				return 0;
			}
		
		 
		 
	}
	




@Override
public DemandDraftBean getDemandDraft(int tranId) throws BankException {

	String selectQuery = "select * from dd where transaction_id = ?";
	
	try{
		
		PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery);
	
		selectStatement.setInt(1, tranId);
		
		ResultSet result = selectStatement.executeQuery();
	
while (result.next()) {
			
			int tranid = result.getInt(1);
			
			String Name = result.getString(2);
			
			String MobNo = result.getString(3);
			
			String InFavour = result.getString(4);
			
			String DdAmount = result.getString(6);
			
			double com= result.getDouble(7);
			
			String Remarks = result.getString(8);
		
			DemandDraftBean dd = new DemandDraftBean();
			dd.setTranId(tranId);
			dd.setName(Name);
			dd.setMobNo(MobNo);
			dd.setInFavour(InFavour);
			dd.setDdAmount(DdAmount);
			dd.setComm(com);
			dd.setRemarks(Remarks);
			return dd;

}
	

	} catch(SQLException e){
		
		e.printStackTrace();
		
		throw new BankException("DD not found",e);
	}
	
	return null;
}



	
	
}
